
import React, { useState } from 'react';

function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async () => {
    // TODO: Call backend for login
    alert('Logging in...');
  };

  return (
    <div className="p-8">
      <h1 className="text-2xl mb-4">Login</h1>
      <input type="email" placeholder="Email" className="block mb-2" onChange={e => setEmail(e.target.value)} />
      <input type="password" placeholder="Password" className="block mb-4" onChange={e => setPassword(e.target.value)} />
      <button className="bg-blue-500 text-white px-4 py-2" onClick={handleLogin}>Login</button>
    </div>
  );
}

export default LoginPage;
