
import React from 'react';

function Dashboard() {
  return (
    <div className="p-8">
      <h1 className="text-2xl">Welcome to Crypto Exchange</h1>
      <p>Your balance: [coming soon]</p>
    </div>
  );
}

export default Dashboard;
